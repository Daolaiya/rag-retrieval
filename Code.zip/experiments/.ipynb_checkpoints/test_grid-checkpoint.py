from pathlib import Path
print(Path(__file__).resolve(), Path(__file__).resolve().parent.parent, sep="\n")
